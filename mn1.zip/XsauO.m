function [juc] = XsauO (juc)

  juc = input ( "X sau O ? (or q to quit) ", 'c' );
  while ( juc != 'X' && juc != 'O' && juc != 'q' )
    juc = input ( "Eroare la introducere. X sau O ? (or q to quit) ", 'c' );
    endwhile
    
  endfunction