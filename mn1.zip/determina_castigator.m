function [castig] = determina_castigator (castig, juc, calc)

  if castig == juc
    disp("Bravo! Ai castigat!");
    endif
  if castig == calc
    disp("Imi pare rau, ai pierdut partida.");
    endif
  if castig == '0'
    disp("Este egalitate.");
    endif
      
  endfunction