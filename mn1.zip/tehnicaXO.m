function [poz] = tehnicaXO (XO, juc, calc)

  poz = verifica_diagonala(XO, juc);
  if ( poz == 0 )
    poz = verifica_coloana(XO, juc);
    endif
  if ( poz == 0 )
    poz = verifica_linie(XO, juc);
    endif
  if ( poz == 0 )
    poz = verifica_diagonala(XO, calc);
    endif
  if ( poz == 0 )
    poz = verifica_coloana(XO, calc);
    endif
  if ( poz == 0 )
    poz = verifica_linie(XO, calc);
    endif
  endfunction