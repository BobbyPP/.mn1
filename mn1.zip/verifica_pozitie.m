function [poz] = verifica_pozitie (poz, XO, ch)
  
  verif = -1;
  while verif != 1
    if ( verif == -1 )
      poz = input ( "Pozitia:", 'd' );
      endif
    poz = str2num(poz);
    l = floor( (poz - 1)/3 ) + 1;
    c = modulo( poz - 1, 3 ) + 1;
    if poz < 1 || poz > 9
      poz = input( "Pozitia trebuie sa apartina intervalului 1...9. Pozitia:", 'd');
      verif = 0;
    else
      if XO(l, c) == 'X' || XO(l, c) == 'O'
        verif = 0;
        poz = input ( "Pozitia este deja ocupata. Incearca alta. Pozitia:", 'd');
      else
        verif = 1;
        endif
      endif
   endwhile
  
  endfunction