function [castig] = castig_linie (XO, ch)
  
  castig = '0';
  i = 1;
  while i <= 3
    pe_linie = 0;
    for j = 1 : 3
      if XO(i, j) == ch
        pe_linie = pe_linie + 1;
        endif
      endfor
    if pe_linie == 3
      castig = ch;
      endif
    i = i + 1;
    endwhile
      
  endfunction