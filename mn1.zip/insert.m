function [XO] = insertch (poz, XO, ch)

  l = floor( (poz - 1)/3 ) + l;l
  c = modulo( poz - 1, 3 ) + 1;c
  
  endfunction