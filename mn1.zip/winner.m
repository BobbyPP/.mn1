function [castig] = winner (XO, ch)

  castig = '0';
  castig = castig_linie(XO, ch);
  castig = castig_coloana(XO, ch);
  castig = castig_diagonala(XO, ch);
  
  endfunction