function [poz] = ultima_pozitie (XO)

  for i = 1 : 3
    for j = 1 : 3
      if XO(i, j) == 'X' || XO(i, j) == 'O'
        poz = (i - 1)*3 + j;
        endif
      endfor
    endfor
  
  endfunction