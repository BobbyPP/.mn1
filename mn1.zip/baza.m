function vb2 = baza(sursa,b1,b2)

  sursa = num2str(sursa);
  vb1 = toascii(sursa); %formarea vectorului ce contine codul ASCII al fiecarei 'cifre' din numarul sursa
  len1 = length(vb1);
  
  for i = 1 : len1      %transformarea fiecarui cod ASCII in 'cifra' corespunzatoare (1->'1', 2->'2', ..., 9->'9', a->'10', b->'11',...)
    if vb1(i)<=57
      vb1(i) = vb1(i) - 48;
      endif
    if vb1(i)>=97
      vb1(i) = vb1(i) - 87;
      endif
    endfor
  
  b10 = 0;              %b10 este numarul sursa, scris in baza zece
  
  for i = 1 : len1      %scrierea in baza 10 a lui b10
    b10 = b10 + vb1(i) * b1^(len1 - i);
    endfor
  
  i = 1;
  while b10 != 0
    vb2aux(i) = b10 - b2 * floor(b10/b2);   %formarea vectorului vb2aux ce are ca elemente cifrele numarului din baza b2, in ordine inversa
    b10 = floor(b10/b2);
    i++;
    endwhile
  
  i = i - 1;
  
  for j = 1 : i                 %inversarea ordinii asa incat vectorului vb2 sa aiba ca elemente cifrele numarului din baza b2, in ordinea corecta.
    ch = vb2aux(i - j + 1);
    if ch < 10
      d = char ( ch + 48 );
      endif
    if ch >= 10
      d = char( ch + 87 );      %transformarea elementelor vectorului vb2 in caractere
      endif
    vb2(j) = d;
    endfor
  
  endfunction