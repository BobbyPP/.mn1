function [poz] = alege_aleator (XO)
  
  alege = zeros(1, 9);
  indice = 0;
  for i = 1 : 3
    for j = 1 : 3
      if XO(i, j) != 'X' && XO(i, j) != 'O'
        indice = indice + 1;
        alege(indice) = (i - 1)*3 + j;
        endif
      endfor
    endfor
  indice_random = modulo( floor(betarnd(1,1)*10), indice ) + 1;
  poz = alege(indice_random);
  
  endfunction