function [XO] = insertch (poz, XO, ch)

  l = floor( (poz - 1)/3 ) + 1;
  c = modulo( poz - 1, 3 ) + 1;
  XO(l, c) = ch;
  
  endfunction