function [] = joc()
  %initializari de scor si de pozitie
  juc = '0';
  scorejuc = 0;
  scorecalc = 0;
  poz = 0;
  
  while juc != 'q'  %jocul se va opri numai atunci cand jucatorul apasa 'q' (la inceputul unei partide)
    juc = XsauO(juc); %jucatorul va trebui sa selecteze cu care dintre 'X' si 'O' doreste sa joace (alegerea este valabila numai pentru partida curenta)
    if juc == 'X'   %atribuirea piesei cu care va juca calculatorul
      calc = 'O';
    else
      calc = 'X';
      endif
    castig = '0';
    XO = ['1','2','3';'4','5','6';'7','8','9']; %initializarea matricei care va reprezenta 'tabla' de joc. Pozitiile acesteia sunt numerotate de la 1 la 9.
    nr_busy = 0;
    if juc == 'X' %cazul in care jucatorul joaca cu 'X', iar jucatorul, in mod evident, cu 'O' ; jucatorul va avea mutarile impare, iar calculatorul va avea mutarile pare
      printf( "Pozitiile sunt numerotate de la 1 la 9, ca mai jos.\nVa trebui sa alegi numarul corespunzator pozitiei\nunde doresti sa muti.\n\n" );
      afis(XO); %afisarea tablei de joc in faza initiala (nimeni nu a facut vreo mutare)
      while nr_busy < 9 && castig == '0'  %conditia de continuare a jocului (partida se opreste cand conditia nu mai este indeplinita)
        if modulo( nr_busy, 2 ) == 0  %conditia care stabileste ca jucatorul este la mutare
          poz = verifica_pozitie(poz, XO, juc); %verificarea cazului in care a fost introdus un numar in intervalul [1,9], si, daca s-a introdus corect, a cazului in care a fost ocupata deja pozitia respectiva fie de un 'X', fie de un 'O' 
          XO = insertch(poz, XO, juc);  %inserarea 'X'-ului pe tabla
          nr_busy = nr_busy + 1;  %nr_busy reprezinta numarul de pozitii ocupate (care nu mai sunt disponibile)
          disp("Afisare tabla(dupa ce ai mutat tu):\n");
          afis(XO);
          if nr_busy >= 5 %daca numarul de celule ocupate este mai mic decat 5, nu are cum sa se indeplineasca conditia de castig sau de egalitate. Se poate indeplini numai in cazul in care sunt ocupate 5 sau mai multe celule ( <= 9 )
            castig = castig_joc(XO);  %functia castig_joc evalueaza cine dintre 'X' si 'O' a castigat partida (daca a castigat), prin verificarea fiecarei linii, coloane si diagonale si stabilirea daca pe toate cele trei pozitii de pe linia, coloana sau diagonala respectiva se afla 'X' sau 'O'
            endif
          endif
        if modulo( nr_busy, 2 ) == 1 && nr_busy != 9 && castig == '0' %conditia care stabileste ca este calculatorul la mutare
          efectuare_mutare = 0; %efectuare_mutare verifica daca a facut sau nu calculatorul mutarea
          poz = 0;
          poz = tehnicaXO(XO, juc, calc); %afunctia tehnicaXO stabileste un rationament pentru calculator, despre unde ar fi mai avantajos (pentru el) sa mute (de exemplu: cand jucatorul a ocupat doua pozitii pe aceeasi linie sau aceeasi coloana, sau aceeasi diagonala, iar a treia nu a fost inca ocupata, calculatorul o ocupa, insa NUMAI in cazul in care el nu are ocupate doua pozitii pe o linie sau coloana sau diagonala (pentru cazul in care calculatorul are ocupate cu piesa lui doua astfel de pozitii, o completeaza pe a treia, indiferent de ce pozitii are ocupate jucatorul (singura conditie este ca cea de a treia pozitie sa nu fie ocupata nici de 'X', nici de 'O' in acel moment)) 
          if ( poz != 0 ) %daca s-a gasit, prin rationamentele de mai sus, o pozitie ( poz ) convenabila pe care sa mute calculatorul
            XO = insertch(poz, XO, calc); %inserare element pe pozitia poz
            disp("Afisare tabla(dupa ce a mutat si calculatorul):\n");
            afis(XO); %afisare tabla (se intampla dupa fiecare mutare, fie a jucatorului, fie a caclulatorului)
            nr_busy = nr_busy + 1;
            efectuare_mutare = 1; %calculatorul a facut mutarea
            endif
          if ( efectuare_mutare == 0 )  %cazul in are nu s-a gasit pozitia convenabila, deci calculatorul nu a mutat
            poz = alege_aleator(XO);  %calculatorul va alege o pozitie libera, aleatoare, pe care sa mute
            XO = insertch(poz, XO, calc); %inserare element pe pozitia poz
            disp("Afisare tabla(dupa ce a mutat si calculatorul):\n");
            afis(XO);
            nr_busy = nr_busy + 1;
            endif
          if nr_busy >= 5 %daca numarul de celule ocupate este mai mare sau egal cu 5 (conditia necesara dar nu si suficienta pentru evaluarea partidei)
            castig = castig_joc(XO);  %functia castig_joc evalueaza cine dintre 'X' si 'O' a castigat partida (daca a castigat), prin verificarea fiecarei linii, coloane si diagonale si stabilirea daca pe toate cele trei pozitii de pe linia, coloana sau diagonala respectiva se afla 'X' sau 'O'
            endif
          endif
        endwhile
      if nr_busy == 8 && castig == '0'  %daca jucatorul a inceput primul partida, si s-a ajuns la a noua mutare, aceasta va fi facuta de catre jucator
        poz = ultima_pozitie(XO); %functia ultima_pozitie returneaza pozitia care a ramas neocupata dupa primele 8 mutari
        insertch(poz, XO, juc); %inserare piesa(a jucatorului) pe pozitia poz
        nr_busy = nr_busy + 1;
        castig = castig_joc(XO);
        endif
      endif
    
    if juc == 'O' %cazul in care calculatorul joaca cu 'X', iar jucatorul cu 'O'; se aplica acelasi algoritm ca mai sus, decat ca se inverseaza ordinea mutarilor: jucatorul va avea mutarile pare, iar calculatorul pe cele impare
      printf( "Pozitiile sunt numerotate de la 1 la 9, ca mai jos.\nVa trebui sa alegi numarul corespunzator pozitiei\nunde doresti sa muti.\n\n" );
      afis(XO);
      while nr_busy < 9 && castig == '0'
        if modulo( nr_busy, 2 ) == 0
          efectuare_mutare = 0;
          poz = 0;
          poz = tehnicaXO(XO, juc, calc);
          if ( poz != 0 )
            XO = insertch(poz, XO, calc);
            disp("Afisare tabla(dupa ce a mutat si calculatorul):\n");
            afis(XO);
            nr_busy = nr_busy + 1;
            efectuare_mutare = 1;
            endif
          if ( efectuare_mutare == 0 )
            poz = alege_aleator(XO);
            XO = insertch(poz, XO, calc);
            disp("Afisare tabla(dupa ce a mutat si calculatorul):\n");
            afis(XO);
            nr_busy = nr_busy + 1;
            endif
          if nr_busy >= 5
            castig = castig_joc(XO);
            endif
          endif
        if modulo( nr_busy, 2 ) == 1 && nr_busy != 9 && castig == '0'
          poz = verifica_pozitie(poz, XO, juc);
          XO = insertch(poz, XO, juc);
          nr_busy = nr_busy + 1;
          disp("Afisare tabla(dupa ce ai mutat tu):\n");
          afis(XO);
          if nr_busy >= 5
            castig = castig_joc(XO);
            endif
          endif
        endwhile
      if nr_busy == 8 && castig == '0'
        poz = ultima_pozitie(XO);
        insertch(poz, XO, juc);
        nr_busy = nr_busy + 1;
        castig = castig_joc(XO);
        endif
      endif
      
    if castig == juc  %variabila castig a stabilit daca partida are castigator sau nu. Este '0' daca partida nu a fost castigata de nimeni (egalitate), 'X' in cazul in care cine a jucat cu 'X' a castigat partida, sau 'O' in cazul in care cine a jucat cu 'O' a castigat partida
      printf("Bravo! Ai castigat partida!\n");
      scorejuc = scorejuc + 1;
      endif
    if castig == calc
      disp("Imi pare rau, ai pierdut partida.\n");
      scorecalc = scorecalc + 1;
      endif
    if castig == '0' && juc != 'q'
      disp("Este egalitate.\n");
      endif
    printf ("\nScor (tu-calculator): %d-%d\n\n", scorejuc, scorecalc);  %afisarea scorului (cate partide a castigat jucatorul si cate partide a castigat calculatorul)
    endwhile
  endfunction