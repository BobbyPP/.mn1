function [castig] = castig_coloana (XO, ch)
  
  castig = '0';
  j = 1;
  while j <= 3
    pe_coloana = 0;
    for i = 1 : 3
      if XO(i, j) == ch
        pe_coloana = pe_coloana + 1;
        endif
      endfor
    if pe_coloana == 3
      castig = ch;
      endif
    j = j + 1;
    endwhile
      
  endfunction