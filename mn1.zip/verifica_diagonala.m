function [poz] = verifica_diagonala (XO, ch)

  poz = 0;
  pe_diagonala = 0;
  for i = 1 : 3
    if XO(i, i) != ch && ( XO(i, i) == 'X' || XO(i, i) == 'O' )
      pe_diagonala = pe_diagonala + 1;
      endif
    endfor
  if pe_diagonala == 2
    for i = 1 : 3
      if XO(i, i) != 'X' && XO(i, i) != 'O'
        poz = 4*(i - 1) + 1;
        endif
      endfor
  else
    pe_diagonala = 0;
    for i = 1 : 3
      if XO(i, 4 - i) != ch && ( XO(i, 4 - i) == 'X' || XO(i, 4 - i) == 'O' )
        pe_diagonala = pe_diagonala + 1;
        endif
      endfor
    if pe_diagonala == 2
      for i = 1 : 3
        if XO(i, 4 - i) != 'X' && XO(i, 4 - i) != 'O'
          poz = 2*i+ 1;
          endif
        endfor
      endif
    endif
  endfunction