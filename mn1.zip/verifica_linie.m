function [poz] = verifica_linie (XO, ch)
  
  i = 1;
  poz = 0;
  while i <= 3 && poz == 0
    pe_linie = 0;
    for j = 1 : 3
      if XO(i, j) != ch && ( XO(i, j) == 'X' || XO(i, j) == 'O' )
        pe_linie = pe_linie + 1;
        endif
      endfor
    if pe_linie == 2
      for j = 1 : 3
        if XO(i, j) != 'X' && XO(i, j) != 'O'
          poz = (i - 1)*3 + j;
          endif
        endfor
      endif
    i = i + 1;
    endwhile
  
  endfunction