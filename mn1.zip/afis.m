function [XO] = afis (XO)

  for i = 1 : 3
    for j = 1 : 3
      printf( "%c  ", XO(i, j) );
      endfor
    printf( "\n\n" );
    endfor
    
  endfunction