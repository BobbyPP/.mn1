function Z = zigzag(n)

  if n != 0
    if n == 1     %in caz ca matricea e 1x1, elementul ei va avea valoarea 0
      Z = zeros(1);
    else          %in caz contrar:
      i = 1; j = 1; valcel = 0;
      Z = zeros(n); %initializare matrice zigzag numai cu zero-uri
      for nrpoz = 1 : n - 1 %in acest for, algoritmul de umplere a matricei zig-zag se face numai pe partea matricei de deasupra diagonalei secundare
        if nrpoz - 2*floor(nrpoz/2) != 0  %cazul in care linia lunga (paralela cu diagonala secundara) este a 'nrpoz'-a, unde 'nrpoz' este numar impar
          valcel = valcel + 1;    %'valcel' este valoarea corespunzatoare celulei(elementului) din matrice zigzag
          j = j + 1;
          Z(i, j) = valcel;       %atribuirea valorii celulei (i,j)
          for k = 1 : nrpoz
            j = j - 1;            %
            i = i + 1;            %deplasarea prin celule in directia stanga - jos
            valcel = valcel + 1;
            Z(i, j) = valcel; %atribuirea valorii
            endfor
        else      %cazul in care linia lunga (paralela cu diagonala secundara) este a 'nrpoz'-a, unde 'nrpoz' este numar par
          valcel = valcel + 1;
          i = i + 1;
          Z(i, j) = valcel; %atribuirea valorii celulei (i,j)
          for k = 1 : nrpoz
            j = j + 1;  %
            i = i - 1;  %deplasarea prin celule in directia dreapta-sus
            valcel = valcel + 1;
            Z(i, j) = valcel; %atribuirea valorii
            endfor
          endif
        endfor
      
      for nrpoz = n - 2 : -1 : 1  %in acest for, algoritmul de umplere a matricei zig-zag se face numai pe partea matricei dedesubtul diagonalei secundare
        if nrpoz - 2*floor(nrpoz/2) != 0  %acelasi algoritm ca si la primul for; deplasarea principala este spre elementul din dreapta - jos
          valcel = valcel + 1;
          i = i + 1;
          Z(i, j) = valcel;
          for k = 1 : nrpoz
            i = i + 1;
            j = j - 1;
            valcel = valcel + 1;
            Z(i, j) = valcel;
            endfor
        else
          valcel = valcel + 1;
          j = j + 1;
          Z(i, j) = valcel;
          for k = 1 : nrpoz
            i = i - 1;
            j = j + 1;
            valcel = valcel + 1;
            Z(i, j) = valcel;
            endfor
          endif
        endfor
      
      Z(n, n) = n^2 - 1;  %deoarece algoritmul de mai sus nu se aplica si pentru ultimul element (cel din dreapta - jos), i se atribuie valoarea corespunzatoare (n^2 - 1)
      endif
    endif
    
endfunction