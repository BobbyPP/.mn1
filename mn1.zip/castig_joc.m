function [castig] = castig_joc (XO)

  castig = castig_coloana(XO, 'X');
  if castig == '0'
    castig = castig_linie(XO, 'X');
    endif
  if castig == '0'
    castig = castig_diagonala(XO, 'X');
    endif
  if castig == '0'
    castig = castig_coloana(XO, 'O');
    endif
  if castig == '0'
    castig = castig_linie(XO, 'O');
    endif
  if castig == '0'
    castig = castig_diagonala(XO, 'O');
    endif
    
  endfunction