function [castig] = castig_diagonala (XO, ch)

  castig = '0';
  pe_diagonala = 0;
  for i = 1 : 3
    if XO(i, i) == ch
      pe_diagonala = pe_diagonala + 1;
      endif
    endfor
  if pe_diagonala == 3
    castig = ch;
  else
    pe_diagonala = 0;
    for i = 1 : 3
      if XO(i, 4 - i) == ch
        pe_diagonala = pe_diagonala + 1;
        endif
      endfor
    if pe_diagonala == 3
      castig = ch;
      endif
    endif
  
  endfunction