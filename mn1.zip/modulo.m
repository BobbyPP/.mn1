function [x] = modulo (x, y)

  x = x - y*floor(x/y);
  
  endfunction