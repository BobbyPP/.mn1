function [poz] = verifica_coloana (XO, ch)
  
  j = 1;
  poz = 0;
  while j <= 3 && poz == 0
    pe_coloana = 0;
    for i = 1 : 3
      if XO(i, j) != ch && ( XO(i, j) == 'X' || XO(i, j) == 'O' )
        pe_coloana = pe_coloana + 1;
        endif
      endfor
    if pe_coloana == 2
      for i = 1 : 3
        if XO(i, j) != 'X' && XO(i, j) != 'O'
          poz = (i - 1)*3 + j;
          endif
        endfor
      endif
    j = j + 1;
    endwhile
  
  endfunction